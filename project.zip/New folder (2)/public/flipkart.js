// var url = window.location.href;
// var regex = new RegExp("[pid]{3}=[A-Z 0-9]{16}");


// console.log("hello from flipkart.js");

// if (url.match(regex)) {

//   console.log("inside if loop");
//   var pathname = new URL(url).pathname.split('/');

//   var producttitle = pathname[1];
//   console.log('url of the selected product is :',producttitle);

//   // var data = {
//   //   url: 'https://www.flipkart.com/apple-iphone-8-plus-space-grey-64-gb/p/itmexrgvehtzhh9v?pid=MOBEXRGVQKBREZP8&srno=s_1_1&otracker=search&lid=LSTMOBEXRGVQKBREZP8PI8YSV&fm=organic&iid=5a5900b3-08e2-4b53-931d-601f03b22c3c.MOBEXRGVQKBREZP8.SEARCH&qH=0b3f45b266a97d70'

//   // };

//   // $http.post("http://127.0.0.1:3000/flipkart", data).success(function (data, status) {
//   //   console.log('Data posted successfully');
//   // });
// }
// console.log("bye from flipkart.js");


// // }

// // // 	function httpGetAsync(theUrl, callback)
// // // {
// // //   var xmlHttp = new XMLHttpRequest();
// // //   xmlHttp.onreadystatechange = function() {
// // //     if (xmlHttp.readyState == 4 && xmlHttp.status == 200)
// // //       callback(xmlHttp.responseText);
// // //     }
// // //    xmlHttp.open("POST", theUrl, true); // true for asynchronous
// // //    xmlHttp.send(producttitle);
// // // }


// // // httpGetAsync("http://127.0.0.1:3000/flipkart", function(response) {
// // //   console.log("recieved ... ", response);
// // // });
// // // }else{

// // // 	console.log(error);
// // // }