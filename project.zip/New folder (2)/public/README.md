# chrome-extension-frontend
A chrome extension for price comparison front end.
We built this project as our college minor project.
It uses Nodejs on its backend.
