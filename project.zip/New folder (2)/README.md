# commodity-search
download as zip or clone this repo.
Once downloaded or cloned follow this steps:
1. npm install - where package.json is present(root directory)
2. run project as- nodemon app.js

for testing, i have used online db hosting on mlab.

Please change the var db accordingly in the respective files.


