var express = require('express');
var router = express.Router();
var Url = require('../model/url');
var mongoose = require('mongoose');
var LocalStorage = require('node-localstorage').LocalStorage;
localStorage = new LocalStorage('./scratch');



 var db = 'mongodb://localhost/flipkart';
// var db = 'mongodb://products:Akshay123@ds159129.mlab.com:59129/commodity-search';
mongoose.connect(db);

var toScrapper;
var fs = require('fs');
var request = require('request');
var cheerio = require('cheerio');


var Mobiles = require('../model/flipkart');
var bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({
    extended: true
}));


//for flipkart
router.post('/amazon', function (req,res){
    // var data = req.body;
  
    // var link = new Url(data);
    // localStorage.setItem("url","google.com");
    // console.log("local storage fetched data ",localStorage.getItem("url"));
    // link.save(function (error, url) {
    //   if (error) {
    //     console.log(error);
    //   } else {
    //     res.status(200).send();
    //   }
    // });
    
    let body="";
    req.on('data', chunk => {
        body += chunk.toString(); // convert Buffer to string
    });
    req.on('end', () => {
        //console.log('body = ',body);
        toScrapper = body;
        // console.log('to scrapper ', toScrapper);
        res.status(200).send(body);
        res.end('ok');
    });
  
    
  });

  //end of flipkart router


// console.log("outside fo the router,post", toScrapper);

router.post('/', function (req, res) {

//console.log("ok");
   var pid,title, price, imageurl, color , Producturl;
    var json = {

    pid: "1",  
    title: "1",
    imageurl: "1",
    price: "1",
    Producturl: "1",
    color: "1"

    };


    //   // Mobiles.create({

    //   //     Producturl: req.body.Producturl

    //   //   },

      var producturl1 = {

     url : ""
    };
   
    var purl = "";

    //scrapper start:
    let body="";
    req.on('data', chunk => {
        body += chunk.toString(); // convert Buffer to string
    });
    req.on('end', () => {
        //console.log('body = ',body);
        // purl = body;
        // console.log('/ to purl ', purl);
        // console.log(body);
         producturl1.url = body;
         var o = producturl1.url;
         var purl = JSON.parse(o);
        // console.log('string :',purl);
  
       //SCRAPER


    
request(purl, function(error, response, html) {
               
        
    if (!error && response.statusCode == 200) {
        
           var $ = cheerio.load(html);
             var title, price, description , url;
    var json = { title : "", price : "", description : "" , url : ""};

       
       
             //product title
         $(' span#productTitle ').each(function(i, element) {
            var el = $(this);
            var title = el.text().trim();
           
           console.log(title);
            json.title = title;
        })


                   //price 
          $(' td.a-span12 span.a-color-price ').each(function(i, element) {
            var el = $(this);
            var price = el.text();
           console.log(price);
            json.price = price;
        })
     
     


    

            Mobiles.find({
                    "$or": [{
                        "$text": {
                            "$search": json.title
                        }
                    }]
                }, {
                    "score": {
                        "$meta": "textScore"
                    }
                })
                .sort({
                    "score": {
                        "$meta": "textScore"
                    }
                })
                .limit(2)
                .exec(function (err, items) {
                    if (err) console.log("Error Finding Query " + err);

                    res.send(items);
                    console.log(items);
                });


        }
    })




        // res.status(200).send(purl);
        // res.end('ok');
    })

    //console.log("purl: ",toScrapper);


})

module.exports = router;